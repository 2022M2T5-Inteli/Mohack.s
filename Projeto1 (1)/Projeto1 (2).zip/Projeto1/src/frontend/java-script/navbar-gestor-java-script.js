//abre o pagina com eixos da agenda educacional
function abrePaginaEixos(){
    document.location.href="pagina-abrir-questionario-agenda-educacional.html"
}
//quando clicar no botao comeca o questionario de agrenda educacional
function abreQuestionario(){
    document.location.href="pagina-comecar-questionario-agenda-educacional.html"
}
function abrePaginaEixos2(){
    document.location.href="pagina-abrir-questionario-sistema-de-gestao.html"
}
//a funcao abre o questionario de sistema de gestao
function abreQuestionarioDois(){
    document.location.href="pagina-comecar-questionario-gestao-pessoas.html" 
}
//abre o questionario de gestao de pessoas
function abrePaginaEixos3(){
    document.location.href="pagina-abrir-questionario-gestao-pessoas.html"
}
//comeca o questionario de gestao de pessoas
function abreQuestionarioTres(){
    document.location.href="pagina-comecar-questionario-gestao-pessoas.html"
}

