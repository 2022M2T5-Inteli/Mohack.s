//Funções que levam o usuario para diferentes paginas de identificacao dependendo do botão selecionado
function abrePaginaLoginGestorEscola(){
    document.location.href="../paginacadastroescolas/paginacadastroescolas2.html";
}

function abrePaginaLoginAgenteFalconi(){
    document.location.href="../paginacadastrofalconi/paginacadastrofalconi.html";
}

function abrePaginaLoginGestorRedes(){
    document.location.href="../pagina-identificacao-gestor-de-redes/pagina-identificacao-gestor-de-redes.html";
}

function abrePaginaGestorEscola(){
    document.location.href="./pagina-tres-grandes-eixos.html";
}

function abrePaginaCadastroPerguntas(){
    document.location.href="./cadastro-de-perguntas.html";
}

function abrePaginaQuestionarioPerguntas(){
    document.location.href="./questionario-perguntas.html";
}
function login(){
    document.location.href="../paginalogin/paginalogin.html";
}

function cadastro(){
    document.location.href="./paginaeusou.html";
}